window.__STANDALONE__ = true;
window.__EXTENSION__ = true;
