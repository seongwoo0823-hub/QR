(function () {
  const STANDALONE = !!window.__STANDALONE__;
  const EXT = !!window.__EXTENSION__;
  // Chrome 웹 스토어에 올린 뒤 주소를 넣으면 '크롬 확장' 탭에 스토어 버튼이 나타나요.
  const STORE_URL = "";
  if (EXT) document.documentElement.classList.add("ext");
  const $ = (id) => document.getElementById(id);
  const urlEl = $("url"), note = $("note"), qrBox = $("qr"), target = $("target"), kind = $("kind");
  const fg = $("fg"), bg = $("bg"), clean = $("clean");
  const btnShort = $("shorten"), btnCopy = $("copy"), shortNote = $("short-note"), compare = $("compare");
  const btnPng = $("dl-png"), btnSvg = $("dl-svg"), status = $("status");
  const radio = (name) => document.querySelector('input[name="' + name + '"]:checked').value;

  if (window.qrcode && qrcode.stringToBytesFuncs && qrcode.stringToBytesFuncs["UTF-8"]) {
    qrcode.stringToBytes = qrcode.stringToBytesFuncs["UTF-8"];
  }

  // ---------- link handling ----------
  const TRACKING = [/^utm_/i, /^fbclid$/i, /^gclid$/i, /^gclsrc$/i, /^dclid$/i, /^msclkid$/i, /^yclid$/i,
    /^igshid$/i, /^igsh$/i, /^si$/i, /^mc_cid$/i, /^mc_eid$/i, /^_hsenc$/i, /^_hsmi$/i, /^mkt_tok$/i,
    /^ref_src$/i, /^ref_url$/i, /^spm$/i, /^_ga$/i, /^_gl$/i, /^oly_enc_id$/i, /^oly_anon_id$/i,
    /^vero_id$/i, /^wickedid$/i, /^twclid$/i, /^ttclid$/i, /^li_fat_id$/i, /^s_cid$/i, /^feature$/i];

  function normalize(raw) {
    const t = raw.trim();
    if (!t) return { text: "", isUrl: false, note: "" };
    if (/^https?:\/\//i.test(t)) return { text: t, isUrl: true, note: "" };
    if (/^[a-z][a-z0-9+.-]*:/i.test(t)) return { text: t, isUrl: false, note: "" };
    if (/^[^\s]+\.[a-z]{2,}([\/?#:].*)?$/i.test(t)) return { text: "https://" + t, isUrl: true, note: "앞에 https:// 를 붙였어요." };
    return { text: t, isUrl: false, note: "웹 주소가 아니라서 입력한 글자 그대로 QR 코드에 담았어요." };
  }

  function stripTracking(u) {
    try {
      const url = new URL(u);
      const keep = [];
      let removed = 0;
      url.searchParams.forEach((v, k) => {
        if (TRACKING.some((re) => re.test(k))) removed++; else keep.push([k, v]);
      });
      if (!removed) return { text: u, removed: 0 };
      url.search = "";
      keep.forEach(([k, v]) => url.searchParams.append(k, v));
      let out = url.toString();
      if (!keep.length) out = out.replace(/\?$/, "");
      return { text: out, removed };
    } catch { return { text: u, removed: 0 }; }
  }

  let short = null; // { from, url }
  let currentText = "";
  let currentKind = "";
  let matrixCache = null;

  function resolveLink() {
    const n = normalize(urlEl.value);
    if (!n.text) return { ...n, original: "", cleaned: "", final: "", removed: 0 };
    let cleaned = n.text, removed = 0;
    if (n.isUrl && clean.checked) ({ text: cleaned, removed } = stripTracking(n.text));
    const final = short && short.from === cleaned ? short.url : cleaned;
    return { ...n, original: n.text, cleaned, final, removed };
  }

  // ---------- QR ----------
  function buildMatrix(text, level) {
    const qr = qrcode(0, level);
    qr.addData(text, "Byte");
    qr.make();
    const n = qr.getModuleCount(), m = [];
    for (let r = 0; r < n; r++) { const row = []; for (let c = 0; c < n; c++) row.push(qr.isDark(r, c)); m.push(row); }
    return { matrix: m, n };
  }
  function toSvg(matrix, n, margin, fgc, bgc) {
    const total = n + margin * 2;
    let d = "";
    for (let r = 0; r < n; r++) {
      let c = 0;
      while (c < n) {
        if (matrix[r][c]) { let s = c; while (c < n && matrix[r][c]) c++; d += "M" + (s + margin) + " " + (r + margin) + "h" + (c - s) + "v1h-" + (c - s) + "z"; }
        else c++;
      }
    }
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + total + " " + total + '" shape-rendering="crispEdges"><rect width="' + total + '" height="' + total + '" fill="' + bgc + '"/><path d="' + d + '" fill="' + fgc + '"/></svg>';
  }
  function toPngBlob(matrix, n, margin, fgc, bgc, px) {
    const total = n + margin * 2, scale = Math.max(1, Math.floor(px / total)), size = scale * total;
    const cv = document.createElement("canvas"); cv.width = cv.height = size;
    const ctx = cv.getContext("2d");
    ctx.fillStyle = bgc; ctx.fillRect(0, 0, size, size); ctx.fillStyle = fgc;
    for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (matrix[r][c]) ctx.fillRect((c + margin) * scale, (r + margin) * scale, scale, scale);
    return new Promise((res) => cv.toBlob(res, "image/png"));
  }
  function contrastWarning(a, b) {
    const lum = (hex) => { const v = [1, 3, 5].map((i) => parseInt(hex.substr(i, 2), 16) / 255).map((x) => x <= 0.03928 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4)); return 0.2126 * v[0] + 0.7152 * v[1] + 0.0722 * v[2]; };
    const la = lum(a), lb = lum(b), ratio = (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
    if (ratio < 3) return "코드 색과 배경 색이 비슷해서 휴대폰이 잘 못 읽을 수 있어요.";
    if (la > lb) return "코드가 배경보다 밝으면 일부 카메라가 못 읽어요.";
    return "";
  }

  const EMPTY_QR = qrBox.innerHTML;

  function lineHtml(tagText, text, on) {
    const d = document.createElement("div");
    d.className = "link-line" + (on ? " on" : "");
    const a = document.createElement("span"); a.className = "tag"; a.textContent = tagText;
    const b = document.createElement("span"); b.className = "txt"; b.textContent = text; b.title = text;
    const c = document.createElement("span"); c.className = "len"; c.textContent = [...text].length + "자";
    d.append(a, b, c);
    return d;
  }

  function render() {
    $("fg-val").textContent = fg.value.toUpperCase();
    $("bg-val").textContent = bg.value.toUpperCase();
    $("clear").hidden = !urlEl.value;
    $("paste").hidden = !!urlEl.value;
    status.textContent = ""; status.className = "status";

    const L = resolveLink();
    currentText = L.final;

    // shortening card
    compare.innerHTML = "";
    const variants = [];
    if (L.original) variants.push(["원래", L.original]);
    if (L.removed) variants.push(["정리", L.cleaned]);
    if (short && short.from === L.cleaned) variants.push(["단축", short.url]);
    if (variants.length > 1) {
      variants.forEach(([t, x], i) => compare.append(lineHtml(t, x, i === variants.length - 1)));
      compare.hidden = false;
    } else compare.hidden = true;

    btnCopy.disabled = !L.final;
    btnShort.disabled = !L.isUrl || (short && short.from === L.cleaned) || !STANDALONE;
    if (!STANDALONE) {
      shortNote.textContent = "짧은 링크 만들기는 외부 단축 서비스에 접속해야 해서 홈 화면에 설치한 앱 버전에서 쓸 수 있어요.";
    } else if (!shortNote.dataset.busy) {
      shortNote.textContent = L.removed ? "추적용 꼬리표 " + L.removed + "개를 지웠어요." : "";
    }
    if (!STANDALONE && L.removed) shortNote.textContent = "추적용 꼬리표 " + L.removed + "개를 지웠어요. " + shortNote.textContent;

    if (!L.final) {
      matrixCache = null;
      qrBox.className = "qr-box empty"; qrBox.innerHTML = EMPTY_QR;
      target.textContent = "아직 링크가 없어요"; kind.textContent = "";
      note.textContent = ""; note.className = "note";
      btnPng.disabled = btnSvg.disabled = true;
      return;
    }
    if (!window.qrcode) { note.textContent = "QR 코드 엔진을 불러오지 못했어요. 페이지를 새로 고쳐 주세요."; note.className = "note warn"; return; }

    try {
      const { matrix, n } = buildMatrix(L.final, radio("ecl"));
      matrixCache = { matrix, n };
      qrBox.className = "qr-box";
      qrBox.innerHTML = toSvg(matrix, n, +radio("margin"), fg.value, bg.value);
      qrBox.firstChild.setAttribute("role", "img");
      qrBox.firstChild.setAttribute("aria-label", L.final + " 로 연결되는 QR 코드");
      target.textContent = L.final;
      currentKind = (short && short.from === L.cleaned) ? "단축 링크" : L.removed ? "정리된 링크" : L.isUrl ? "링크" : "텍스트";
      kind.textContent = currentKind + " · " + n + "×" + n + " 칸";
      const w = contrastWarning(fg.value, bg.value);
      note.textContent = w || L.note; note.className = w ? "note warn" : "note";
      btnPng.disabled = btnSvg.disabled = false;
    } catch (e) {
      matrixCache = null;
      qrBox.className = "qr-box empty"; qrBox.textContent = "너무 길어서 QR 코드에 담을 수 없어요";
      target.textContent = ""; kind.textContent = "";
      note.textContent = "링크를 줄이거나 ‘가려져도 읽히는 정도’를 낮춰 보세요."; note.className = "note warn";
      btnPng.disabled = btnSvg.disabled = true;
    }
  }

  // ---------- shortening (is.gd, JSONP; installed version only) ----------
  function isgd(longUrl) {
    return new Promise((resolve, reject) => {
      const cb = "__isgd" + Date.now();
      const s = document.createElement("script");
      const timer = setTimeout(() => { cleanup(); reject(new Error("timeout")); }, 9000);
      function cleanup() { clearTimeout(timer); delete window[cb]; s.remove(); }
      window[cb] = (data) => { cleanup(); data && data.shorturl ? resolve(data.shorturl) : reject(new Error((data && data.errormessage) || "error")); };
      s.onerror = () => { cleanup(); reject(new Error("network")); };
      s.src = "https://is.gd/create.php?format=json&callback=" + cb + "&url=" + encodeURIComponent(longUrl);
      document.head.appendChild(s);
    });
  }
  async function isgdFetch(longUrl) {
    let r;
    try { r = await fetch("https://is.gd/create.php?format=simple&url=" + encodeURIComponent(longUrl)); }
    catch { throw new Error("network"); }
    const t = (await r.text()).trim();
    if (!r.ok || !/^https?:\/\//.test(t)) throw new Error(t.replace(/^Error:\s*/i, "") || "error");
    return t;
  }
  btnShort.addEventListener("click", async () => {
    const L = resolveLink();
    if (!L.isUrl) return;
    btnShort.disabled = true;
    const label = btnShort.querySelector("span"); const prev = label.textContent;
    label.textContent = "만드는 중…";
    shortNote.dataset.busy = "1";
    try {
      const s = EXT ? await isgdFetch(L.cleaned) : await isgd(L.cleaned);
      short = { from: L.cleaned, url: s };
      delete shortNote.dataset.busy;
      render();
      shortNote.textContent = [...L.cleaned].length + "자 → " + [...s].length + "자로 줄였어요. QR 코드도 짧은 링크로 바뀌었어요.";
    } catch (e) {
      delete shortNote.dataset.busy;
      render();
      shortNote.textContent = e.message === "timeout" || e.message === "network"
        ? "단축 서비스에 연결하지 못했어요. 인터넷 연결을 확인하고 다시 눌러 주세요."
        : "이 링크는 줄일 수 없어요: " + e.message;
    } finally { label.textContent = prev; }
  });

  // ---------- copy / paste ----------
  async function copyText(t) {
    try { await navigator.clipboard.writeText(t); return true; }
    catch {
      const ta = document.createElement("textarea"); ta.value = t; ta.setAttribute("readonly", "");
      ta.style.cssText = "position:fixed;opacity:0"; document.body.appendChild(ta); ta.select();
      let ok = false; try { ok = document.execCommand("copy"); } catch {} ta.remove(); return ok;
    }
  }
  btnCopy.addEventListener("click", async () => {
    const ok = await copyText(currentText);
    const label = btnCopy.querySelector("span");
    label.textContent = ok ? "복사됨" : "복사 안 됨";
    setTimeout(() => (label.textContent = "링크 복사"), 1600);
  });
  $("paste").addEventListener("click", async () => {
    try { const t = await navigator.clipboard.readText(); if (t) { urlEl.value = t.trim(); short = null; render(); } }
    catch { urlEl.focus(); note.textContent = "길게 눌러 붙여넣기를 해 주세요."; note.className = "note"; }
  });
  $("clear").addEventListener("click", () => { urlEl.value = ""; short = null; render(); urlEl.focus(); });

  // ---------- downloads ----------
  let downloads = null;
  function fileBase() {
    try { return ("qr-" + new URL(currentText).hostname.replace(/^www\./, "")).replace(/[^a-z0-9.-]/gi, "-").slice(0, 60); }
    catch { return "qr-code"; }
  }
  async function save(kindName) {
    if (!matrixCache) return;
    const { matrix, n } = matrixCache, m = +radio("margin");
    const filename = fileBase() + "." + kindName;
    const data = kindName === "png"
      ? await toPngBlob(matrix, n, m, fg.value, bg.value, +radio("size"))
      : new Blob([toSvg(matrix, n, m, fg.value, bg.value)], { type: "image/svg+xml" });
    if (STANDALONE || !downloads) {
      if (navigator.canShare && kindName === "png" && /iPhone|iPad|Android/i.test(navigator.userAgent)) {
        const file = new File([data], filename, { type: "image/png" });
        if (navigator.canShare({ files: [file] })) {
          try { await navigator.share({ files: [file] }); status.textContent = "공유 시트를 열었어요."; return; } catch (e) { if (e.name === "AbortError") return; }
        }
      }
      const a = document.createElement("a");
      a.href = URL.createObjectURL(data); a.download = filename;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 4000);
      status.textContent = filename + " 저장됨"; status.className = "status ok";
      return;
    }
    try {
      await downloads.save({ filename, data });
      status.textContent = filename + " 저장됨"; status.className = "status ok";
    } catch (e) {
      status.className = "status";
      status.textContent = e && e.code === "declined" ? "저장을 취소했어요." : e && e.code === "rate_limited" ? "잠시 후 다시 눌러 주세요." : "이 화면에서는 저장할 수 없어요.";
    }
  }
  btnPng.addEventListener("click", () => save("png"));
  btnSvg.addEventListener("click", () => save("svg"));

  // ---------- events ----------
  let t;
  urlEl.addEventListener("input", () => { clearTimeout(t); t = setTimeout(render, 100); });
  [fg, bg, clean].forEach((el) => el.addEventListener("input", render));
  document.querySelectorAll('input[type="radio"]').forEach((el) => el.addEventListener("change", render));

  // pre-fill from share target / ?url=
  try {
    const p = new URLSearchParams(location.search);
    const shared = p.get("url") || p.get("text");
    if (shared) { const m = shared.match(/https?:\/\/\S+/); urlEl.value = m ? m[0] : shared; }
  } catch {}

  render();

  if (!STANDALONE && window.claude && typeof window.claude.use === "function") {
    window.claude.use("downloads").then((d) => {
      downloads = d;
      if (!d) { $("dl-row").hidden = true; status.textContent = "이 화면에서는 파일 저장이 안 돼요. QR 코드를 길게 눌러 저장하세요."; }
    }).catch(() => {});
  }

  // ---------- install sheet ----------
  const sheet = $("sheet");
  const ua = navigator.userAgent;
  const isIOS = /iPhone|iPad|iPod/i.test(ua) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  const isAndroid = /Android/i.test(ua);
  const inApp = matchMedia("(display-mode: standalone)").matches || navigator.standalone === true;
  const detected = isIOS ? "ios" : isAndroid ? "android" : "pc";
  let deferred = null;

  $("open-app-sub").textContent = { ios: "아이폰 홈 화면에 추가", android: "안드로이드 홈 화면에 추가", pc: "PC에 앱으로 설치" }[detected];
  if (!STANDALONE) { $("env-box").hidden = false; $("ext-dl").removeAttribute("href"); $("ext-dl").setAttribute("aria-disabled", "true"); $("ext-dl").style.opacity = ".4"; }
  if (STORE_URL) { $("store-box").hidden = false; $("store-link").href = STORE_URL; }

  function showPanel(plat) {
    document.querySelectorAll('input[name="plat"]').forEach((r) => (r.checked = r.value === plat));
    document.querySelectorAll(".panel").forEach((p) => (p.hidden = p.dataset.plat !== plat));
    $("done-box").hidden = !(inApp && plat !== "ext");
    document.querySelectorAll("[data-now]").forEach((b) => (b.hidden = !deferred));
  }
  function openSheet(plat) {
    showPanel(plat);
    if (typeof sheet.showModal === "function") sheet.showModal(); else sheet.setAttribute("open", "");
  }
  function closeSheet() { if (sheet.open) { typeof sheet.close === "function" ? sheet.close() : sheet.removeAttribute("open"); } }
  document.querySelectorAll('input[name="plat"]').forEach((r) => r.addEventListener("change", () => showPanel(r.value)));
  $("install").addEventListener("click", () => openSheet(detected));
  $("open-app").addEventListener("click", () => openSheet(detected));
  $("open-ext").addEventListener("click", () => openSheet("ext"));
  $("sheet-close").addEventListener("click", closeSheet);
  sheet.addEventListener("click", (e) => { if (e.target === sheet) closeSheet(); });
  document.querySelectorAll("[data-now-btn]").forEach((b) => b.addEventListener("click", async () => {
    if (!deferred) return;
    deferred.prompt();
    try { await deferred.userChoice; } catch {}
    deferred = null;
    document.querySelectorAll("[data-now]").forEach((x) => (x.hidden = true));
  }));

  // ---------- PWA ----------
  if (STANDALONE && !EXT) {
    if ("serviceWorker" in navigator) navigator.serviceWorker.register("./sw.js").catch(() => {});
    window.addEventListener("beforeinstallprompt", (e) => {
      e.preventDefault(); deferred = e;
      document.querySelectorAll("[data-now]").forEach((x) => (x.hidden = false));
    });
    window.addEventListener("appinstalled", () => { deferred = null; document.querySelectorAll("[data-now]").forEach((x) => (x.hidden = true)); });
  }

  // ---------- extension: start with the current tab ----------
  if (EXT && window.chrome && chrome.tabs && chrome.tabs.query) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const u = tabs && tabs[0] && tabs[0].url;
      if (u && /^https?:/i.test(u) && !urlEl.value) { urlEl.value = u; render(); }
    });
  }
})();
